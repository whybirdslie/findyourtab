# FindYourTab - Desktop Application

## Quick Start
1. Run `FindYourTab.exe`
2. Install the browser extension from the Chrome Web Store
3. Use Ctrl+Alt+F to toggle the tab finder window

## Features
- View all browser tabs in one place
- Instant tab switching
- Cross-browser support
- Keyboard shortcuts
- System tray integration

## System Requirements
- Windows 10/11
- Chrome, Firefox, Edge, or Opera browser
- 4GB RAM minimum

## Troubleshooting
- If the app doesn't start, run as administrator
- Make sure Windows Defender isn't blocking the executable
- Check that port 8765 and 8000 are available

## Support
Visit: https://github.com/whybirdslie/findyourtab
