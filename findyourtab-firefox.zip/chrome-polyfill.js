if (typeof browser !== 'undefined') {
  chrome = browser;
} 